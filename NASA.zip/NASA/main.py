import requests
import json
from tkinter import *
from tkinter import messagebox, ttk
import webbrowser
from PIL import ImageTk, Image
import turtle
import urllib.request
import time

api_key = "1lWoHlIaOFDy4OJbzZfsKnyA0k9IHxUZAcO7aKMY"


# Function to close button
def close_button():
    """Function to end the program"""
    window.destroy()
    exit()


# Create the main window
window = Tk()
window.title("ISS Location Tracker")
window.configure(bg="navy")
window.geometry("1041x600")

# Insert a background image into tkinter
photo = ImageTk.PhotoImage(Image.open("nasa1.png"))
pic = Label(image=photo)


# Create labels
pic.grid(row=0,column=0, columnspan=10)
month = Label(text="Month:", bg="navy", fg="white", pady=10, padx=10)
month.grid(row=1, column=0)
day = Label(text="Day:", bg="navy", fg="white", pady=10, padx=10)
day.grid(row=1, column=2)
year = Label(text="Year:", bg="navy", fg="white", pady=10, padx=10)
year.grid(row=1, column=4)


# Months
months = ["1","2","3","4","5","6","7","8","9","10","11","12"]
month_combobox = ttk.Combobox(window, values=months, width=10)
month_combobox.grid(row=1, column=1)

# Days
days = ["1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24",
        "25","26","26","27","28","29","30","31"]
day_combobox = ttk.Combobox(window, values=days, width=10)
day_combobox.grid(row=1, column=3)

# Years
years = ["2022","2021","2020","2019","2018","2017","2016","2015","2014","2013","2012","2011","2010","2009",
         "2008","2007","2006","2005","2004","2003","2002","2001","2000","1999","1998","1997","1996","1995"]
year_combobox = ttk.Combobox(window, values=years, width=10)
year_combobox.grid(row=1,column=5)


# Crate the buttons
convert = Button(text="Explore of The Day", width=15)
convert.config(bg="white")
convert.grid(row=1, column=6, sticky="w", pady=10, padx=10)

pic = Button(text="Picture of The Day", width=15)
pic.config(bg="white")
pic.grid(row=2, column=6, sticky="w", padx=10, pady=10)

iss = Button(text="Real-time ISS Location")
iss.config(bg="white")
iss.grid(row=3, column=6, sticky="w", padx=10, pady=10)

ppl = Button(text="The Astronauts on ISS")
ppl.config(bg="white")
ppl.grid(row=4, column=6, sticky="w", padx=10, pady=10)

close = Button(text="Exit", width=15)
close.config(bg="white", command=close_button)
close.grid(row=5, column=6, sticky="w", pady=10, padx=10)

# API
url = f"https://api.nasa.gov/planetary/apod"

# Message to let the user how to use the program
messagebox.showinfo(title="Welcome!", message="Welcome to the program where you can look at information from the NASA"
                                          " taken each day. In order for this program to work, please type dates after"
                                          " 1995. Dates before do not exist within the API.")


def info_date():
    """Prints the required date input from the user."""
    date_data = {
        "api_key": api_key,
        "date": f"{year_combobox.get()}-{month_combobox.get()}-{day_combobox.get()}",
    }
    response = requests.get(url, params=date_data)

    if response:
        data = json.loads(response.text)
        messagebox.showinfo(title="Explanation of the date on space", message=data["explanation"])
        #print(json.dumps(data, indent=4))
    else:
        messagebox.showerror(title="Error.", message="Oops! Seems that you probably typed the wrong date or perhaps"
                                                     " you typed a date before 1995; also, make sure"
                                                     " you are connected to the internet. Please try again.")


convert.config(command=info_date)


def see_picture():
    """Function for the user to see the picture."""
    date_data = {
        "api_key": api_key,
        "date": f"{year_combobox.get()}-{month_combobox.get()}-{day_combobox.get()}",
    }
    response = requests.get(url, params=date_data)

    if response:
        data = json.loads(response.text)
        picture = data["hdurl"]
        # Messagebox to notify
        messagebox.askyesno(title="Picture of the day requested.", message="This button will cause to open the webpage"
                                                                           " is that ok?")
        webbrowser.open_new_tab(picture)
    else:
        messagebox.showerror(title="Error.", message="Oops! Seems that you probably typed the wrong date or perhaps"
                                                     " you typed a date before 1995; also, make sure"
                                                     " you are connected to the internet. Please try again.")


pic.config(command=see_picture)


def iss_people():
    url = "http://api.open-notify.org/astros.json"
    response = urllib.request.urlopen(url)
    result = json.loads(response.read())
    file = open("iss.txt", "w")
    file.write(f"There are currently " + str(result["number"]) + " astronauts on the ISS: \n")
    people = result["people"]
    # Print people on board
    for p in people:
        file.write(p["name"] + " - on board \n")

    # Print longitude and latitude
    url = "http://api.open-notify.org/iss-now.json"
    response = urllib.request.urlopen(url)
    result = json.loads(response.read())

    location = result["iss_position"]
    lat = location["latitude"]
    lon = location["longitude"]

    file.write(f"\nThe ISS current latitude {lat} / longitude {lon}")
    file.close()
    messagebox.showinfo(title="Complete.", message="The results have been saved in 'iss.txt' successfully.")

ppl.config(command=iss_people)


def iss_location():
    # Display the world map
    screen = turtle.Screen()
    screen.setup(1200, 626)
    screen.setworldcoordinates(-180, -90, 180, 90)
    screen.bgpic("map.gif")

    # Display the ISS icon
    screen.register_shape("iss.gif")
    iss = turtle.Turtle()
    iss.shape("iss.gif")
    iss.setheading(45)
    iss.penup()

    # Load the current status of the ISS in the real-time
    while True:
        url = "http://api.open-notify.org/iss-now.json"
        response = urllib.request.urlopen(url)
        result = json.loads(response.read())
        # Get the exact the ISS location
        location = result["iss_position"]
        lat = location["latitude"]
        lon = location["longitude"]
        # Output lon abd lat on the map
        lat = float(lat)
        lon = float(lon)
        print("\nLatitude: " + str(lat))
        print("Longitude: " + str(lon))
        iss.goto(lon, lat)
        time.sleep(5)



iss.config(command=iss_location)

window.mainloop()



